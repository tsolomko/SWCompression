import PackageDescription

let package = Package(
    name: "SWCompression",
    exclude: [
      "Sources/Service/",
      "Tests/"
    ]
)

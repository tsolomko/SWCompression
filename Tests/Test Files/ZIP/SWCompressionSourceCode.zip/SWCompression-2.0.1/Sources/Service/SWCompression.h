//
//  SWCompression.h
//  SWCompression
//
//  Created by Timofey Solomko on 16.10.16.
//  Copyright © 2016 Timofey Solomko. All rights reserved.
//

//! Project version number for SWCompression.
extern double SWCompressionVersionNumber;

//! Project version string for SWCompression.
extern const unsigned char SWCompressionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SWCompression/PublicHeader.h>



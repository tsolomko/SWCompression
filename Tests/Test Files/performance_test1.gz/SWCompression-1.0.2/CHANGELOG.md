# Changelog

v1.0.2
----------------
- Fixed a problem when decompressed amount of data was greater than expected.
- Performance improvement.

v1.0.1
----------------
Fixed several crashes caused by mistyping and shift 'overflow' (when it becomes greater than 15). 

v1.0.0
----------------
Initial release, which features support for Deflate, Gzip and Zlib decompression.

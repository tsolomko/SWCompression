import PackageDescription

let package = Package(
    name: "SWCompression",
    exclude: [
      "Tests/"
    ]
)
